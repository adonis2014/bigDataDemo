flumeng-kafka-plugin
====================

Technical Specifications


Flume 1.4

Kafka 0.8.0 Beta
